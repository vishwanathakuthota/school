<?php
	foreach($install_warnings as $warning)
	{
?>
	<div class="post bump"> 
		<p><?php echo$warning?></p>
<?php
	}
?>
